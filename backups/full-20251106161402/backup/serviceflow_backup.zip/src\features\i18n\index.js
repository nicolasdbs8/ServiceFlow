export { I18N } from "./locales/index";
