import { initPassengersSectionLegacy } from "../../legacy";
import "../../styles/components/passengers.css";
export function initPassengers() {
    initPassengersSectionLegacy();
}
