import { initAirportSectionLegacy } from "../../legacy";
import "../../styles/components/seat-map.css";

export function initSeatMap(): void {
  initAirportSectionLegacy();
}
