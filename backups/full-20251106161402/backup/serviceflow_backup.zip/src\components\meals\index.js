import { initMealSectionLegacy } from "../../legacy";
import "../../styles/components/meals.css";
export function initMeals() {
    initMealSectionLegacy();
}
