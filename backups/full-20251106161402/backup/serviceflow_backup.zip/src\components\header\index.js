import { initFlightFormsLegacy } from "../../legacy";
import "../../styles/components/header.css";
export function initHeader() {
    initFlightFormsLegacy();
}
